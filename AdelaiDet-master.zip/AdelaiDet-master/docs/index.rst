.. AdelaiDet documentation master file, created by
   sphinx-quickstart on Wed Feb 26 15:24:04 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to AdelaiDet's documentation!
=====================================

.. toctree::
   :maxdepth: 2


   modules/index