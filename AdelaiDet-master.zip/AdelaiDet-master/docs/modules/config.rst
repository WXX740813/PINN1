adet.config package
=========================

.. automodule:: adet.config
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:


Config References
-----------------

.. literalinclude:: ../../adet/config/defaults.py
  :language: python
  :linenos:
  :lines: 4-